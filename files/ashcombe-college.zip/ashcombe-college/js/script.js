// ============================================================
// Ashcombe College — shared behavior
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  initNavToggle();
  initCardCatalog();
  initCourseFilter();
  initForms();
  setFooterYear();
});

/* ---------------------------------------------------------
   Mobile nav toggle
--------------------------------------------------------- */
function initNavToggle() {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if (!toggle || !nav) return;

  toggle.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(isOpen));
  });

  // Close menu when a link is chosen (mobile)
  nav.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    });
  });
}

/* ---------------------------------------------------------
   Homepage "card catalog" — rotating index cards
--------------------------------------------------------- */
function initCardCatalog() {
  const stack = document.querySelector('.catalog-stack');
  if (!stack) return;

  const cards = Array.from(stack.querySelectorAll('.index-card'));
  const dotsWrap = document.querySelector('.catalog-dots');
  if (!cards.length) return;

  let current = 0;
  let timer = null;

  // Build dots
  cards.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.setAttribute('aria-label', `Show catalog card ${i + 1} of ${cards.length}`);
    if (i === 0) dot.setAttribute('aria-current', 'true');
    dot.addEventListener('click', () => {
      show(i);
      restartTimer();
    });
    dotsWrap && dotsWrap.appendChild(dot);
  });

  function show(index) {
    cards[current].classList.remove('active');
    const dots = dotsWrap ? Array.from(dotsWrap.children) : [];
    if (dots[current]) dots[current].removeAttribute('aria-current');
    current = index;
    cards[current].classList.add('active');
    if (dots[current]) dots[current].setAttribute('aria-current', 'true');
  }

  function next() {
    show((current + 1) % cards.length);
  }

  function restartTimer() {
    clearInterval(timer);
    timer = setInterval(next, 4200);
  }

  cards[0].classList.add('active');
  restartTimer();

  // Pause on hover/focus for readability
  stack.addEventListener('mouseenter', () => clearInterval(timer));
  stack.addEventListener('mouseleave', restartTimer);
}

/* ---------------------------------------------------------
   Academics page — department filter chips
--------------------------------------------------------- */
function initCourseFilter() {
  const bar = document.querySelector('.filter-bar');
  const rows = document.querySelectorAll('[data-dept]');
  if (!bar || !rows.length) return;

  bar.querySelectorAll('.filter-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      bar.querySelectorAll('.filter-chip').forEach(c => c.setAttribute('aria-pressed', 'false'));
      chip.setAttribute('aria-pressed', 'true');
      const dept = chip.dataset.filter;

      rows.forEach(row => {
        const match = dept === 'all' || row.dataset.dept === dept;
        row.style.display = match ? '' : 'none';
      });
    });
  });
}

/* ---------------------------------------------------------
   Forms — lightweight client-side validation
   (No backend is wired up; this simulates a submission so the
   form is fully interactive. Swap the fake delay for a real
   fetch() call to your endpoint when one exists.)
--------------------------------------------------------- */
function initForms() {
  document.querySelectorAll('form[data-validate]').forEach(form => {
    const status = form.querySelector('.form-status');

    form.querySelectorAll('input, textarea, select').forEach(field => {
      field.addEventListener('blur', () => {
        field.dataset.touched = 'true';
        validateField(field);
      });
      field.addEventListener('input', () => {
        if (field.dataset.touched === 'true') validateField(field);
      });
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let allValid = true;

      form.querySelectorAll('input, textarea, select').forEach(field => {
        field.dataset.touched = 'true';
        if (!validateField(field)) allValid = false;
      });

      if (!allValid) {
        if (status) {
          status.textContent = 'A few fields need a second look before this can be sent.';
          status.className = 'form-status err show';
        }
        const firstInvalid = form.querySelector('.field.invalid input, .field.invalid textarea, .field.invalid select');
        firstInvalid && firstInvalid.focus();
        return;
      }

      const submitBtn = form.querySelector('button[type="submit"]');
      const originalLabel = submitBtn ? submitBtn.textContent : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Sending…';
      }

      // Simulated network round-trip. Replace with a real fetch() to
      // your backend/API endpoint when one is available.
      setTimeout(() => {
        if (status) {
          status.textContent = form.dataset.successMessage ||
            'Received — the registrar\'s office will follow up by email within two business days.';
          status.className = 'form-status ok show';
        }
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = originalLabel;
        }
        form.reset();
        form.querySelectorAll('.field').forEach(f => f.classList.remove('invalid'));
      }, 700);
    });
  });
}

function validateField(field) {
  const wrapper = field.closest('.field');
  if (!wrapper) return true;
  const isValid = field.checkValidity();
  wrapper.classList.toggle('invalid', !isValid);
  return isValid;
}

/* ---------------------------------------------------------
   Footer year
--------------------------------------------------------- */
function setFooterYear() {
  document.querySelectorAll('[data-year]').forEach(el => {
    el.textContent = new Date().getFullYear();
  });
}
